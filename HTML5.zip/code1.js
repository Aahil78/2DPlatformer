gdjs.UndergroundCode = {};
gdjs.UndergroundCode.localVariables = [];
gdjs.UndergroundCode.idToCallbackMap = new Map();
gdjs.UndergroundCode.GDCave_9595Under_9595TileObjects1= [];
gdjs.UndergroundCode.GDCave_9595Under_9595TileObjects2= [];
gdjs.UndergroundCode.GDBackgroundObjects1= [];
gdjs.UndergroundCode.GDBackgroundObjects2= [];
gdjs.UndergroundCode.GDWallObjects1= [];
gdjs.UndergroundCode.GDWallObjects2= [];
gdjs.UndergroundCode.GDMonsterObjects1= [];
gdjs.UndergroundCode.GDMonsterObjects2= [];
gdjs.UndergroundCode.GDCave_9595Under_9595Tile_9595DisappearObjects1= [];
gdjs.UndergroundCode.GDCave_9595Under_9595Tile_9595DisappearObjects2= [];
gdjs.UndergroundCode.GDPlayerObjects1= [];
gdjs.UndergroundCode.GDPlayerObjects2= [];
gdjs.UndergroundCode.GDJumpButtonObjects1= [];
gdjs.UndergroundCode.GDJumpButtonObjects2= [];
gdjs.UndergroundCode.GDMoveJoystickObjects1= [];
gdjs.UndergroundCode.GDMoveJoystickObjects2= [];
gdjs.UndergroundCode.GDKeyObjects1= [];
gdjs.UndergroundCode.GDKeyObjects2= [];
gdjs.UndergroundCode.GDTeleporterObjects1= [];
gdjs.UndergroundCode.GDTeleporterObjects2= [];
gdjs.UndergroundCode.GDCoinsObjects1= [];
gdjs.UndergroundCode.GDCoinsObjects2= [];
gdjs.UndergroundCode.GDTeleporter2Objects1= [];
gdjs.UndergroundCode.GDTeleporter2Objects2= [];


gdjs.UndergroundCode.mapOfGDgdjs_9546UndergroundCode_9546GDMonsterObjects1Objects = Hashtable.newFrom({"Monster": gdjs.UndergroundCode.GDMonsterObjects1});
gdjs.UndergroundCode.mapOfGDgdjs_9546UndergroundCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.UndergroundCode.GDPlayerObjects1});
gdjs.UndergroundCode.mapOfGDgdjs_9546UndergroundCode_9546GDCoinsObjects1Objects = Hashtable.newFrom({"Coins": gdjs.UndergroundCode.GDCoinsObjects1});
gdjs.UndergroundCode.mapOfGDgdjs_9546UndergroundCode_9546GDMonsterObjects1Objects = Hashtable.newFrom({"Monster": gdjs.UndergroundCode.GDMonsterObjects1});
gdjs.UndergroundCode.mapOfGDgdjs_9546UndergroundCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.UndergroundCode.GDPlayerObjects1});
gdjs.UndergroundCode.mapOfGDgdjs_9546UndergroundCode_9546GDKeyObjects1Objects = Hashtable.newFrom({"Key": gdjs.UndergroundCode.GDKeyObjects1});
gdjs.UndergroundCode.mapOfGDgdjs_9546UndergroundCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.UndergroundCode.GDPlayerObjects1});
gdjs.UndergroundCode.mapOfGDgdjs_9546UndergroundCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.UndergroundCode.GDPlayerObjects1});
gdjs.UndergroundCode.mapOfGDgdjs_9546UndergroundCode_9546GDTeleporterObjects1Objects = Hashtable.newFrom({"Teleporter": gdjs.UndergroundCode.GDTeleporterObjects1});
gdjs.UndergroundCode.mapOfGDgdjs_9546UndergroundCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.UndergroundCode.GDPlayerObjects1});
gdjs.UndergroundCode.mapOfGDgdjs_9546UndergroundCode_9546GDTeleporter2Objects1Objects = Hashtable.newFrom({"Teleporter2": gdjs.UndergroundCode.GDTeleporter2Objects1});
gdjs.UndergroundCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.UndergroundCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs.UndergroundCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.UndergroundCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "w");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.UndergroundCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs.UndergroundCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.UndergroundCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.UndergroundCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs.UndergroundCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.UndergroundCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").simulateLeftKey();
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "s");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.UndergroundCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs.UndergroundCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.UndergroundCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").simulateDownKey();
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.UndergroundCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs.UndergroundCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.UndergroundCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").simulateRightKey();
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Monster"), gdjs.UndergroundCode.GDMonsterObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.raycastObject(gdjs.UndergroundCode.mapOfGDgdjs_9546UndergroundCode_9546GDMonsterObjects1Objects, (( gdjs.UndergroundCode.GDMonsterObjects1.length === 0 ) ? 0 :gdjs.UndergroundCode.GDMonsterObjects1[0].getPointX("Raycast X")), (( gdjs.UndergroundCode.GDMonsterObjects1.length === 0 ) ? 0 :gdjs.UndergroundCode.GDMonsterObjects1[0].getPointY("Raycast Y")), 0, 500, runtimeScene.getScene().getVariables().getFromIndex(0), runtimeScene.getScene().getVariables().getFromIndex(1), false);
if (isConditionTrue_0) {
/* Reuse gdjs.UndergroundCode.GDMonsterObjects1 */
{for(var i = 0, len = gdjs.UndergroundCode.GDMonsterObjects1.length ;i < len;++i) {
    gdjs.UndergroundCode.GDMonsterObjects1[i].getBehavior("Animation").setAnimationName("Fire");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Coins"), gdjs.UndergroundCode.GDCoinsObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.UndergroundCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.UndergroundCode.mapOfGDgdjs_9546UndergroundCode_9546GDPlayerObjects1Objects, gdjs.UndergroundCode.mapOfGDgdjs_9546UndergroundCode_9546GDCoinsObjects1Objects, false, runtimeScene, true);
if (isConditionTrue_0) {
/* Reuse gdjs.UndergroundCode.GDCoinsObjects1 */
{for(var i = 0, len = gdjs.UndergroundCode.GDCoinsObjects1.length ;i < len;++i) {
    gdjs.UndergroundCode.GDCoinsObjects1[i].deleteFromScene(runtimeScene);
}
}
{gdjs.evtTools.sound.playSound(runtimeScene, "PickupCoin", false, 80, 1);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Monster"), gdjs.UndergroundCode.GDMonsterObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.UndergroundCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.UndergroundCode.mapOfGDgdjs_9546UndergroundCode_9546GDMonsterObjects1Objects, gdjs.UndergroundCode.mapOfGDgdjs_9546UndergroundCode_9546GDPlayerObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Game Scene", false);
}
{gdjs.evtTools.sound.playSound(runtimeScene, "Death.wav", false, 80, 1);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Key"), gdjs.UndergroundCode.GDKeyObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.UndergroundCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.UndergroundCode.mapOfGDgdjs_9546UndergroundCode_9546GDKeyObjects1Objects, gdjs.UndergroundCode.mapOfGDgdjs_9546UndergroundCode_9546GDPlayerObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.UndergroundCode.GDKeyObjects1 */
{for(var i = 0, len = gdjs.UndergroundCode.GDKeyObjects1.length ;i < len;++i) {
    gdjs.UndergroundCode.GDKeyObjects1[i].deleteFromScene(runtimeScene);
}
}
{runtimeScene.getScene().getVariables().getFromIndex(2).add(1);
}
{gdjs.evtTools.sound.playSound(runtimeScene, "PickupCoin", false, 80, 1);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber() == 1);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cave_Under_Tile_Disappear"), gdjs.UndergroundCode.GDCave_9595Under_9595Tile_9595DisappearObjects1);
{for(var i = 0, len = gdjs.UndergroundCode.GDCave_9595Under_9595Tile_9595DisappearObjects1.length ;i < len;++i) {
    gdjs.UndergroundCode.GDCave_9595Under_9595Tile_9595DisappearObjects1[i].deleteFromScene(runtimeScene);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.UndergroundCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("Teleporter"), gdjs.UndergroundCode.GDTeleporterObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.UndergroundCode.mapOfGDgdjs_9546UndergroundCode_9546GDPlayerObjects1Objects, gdjs.UndergroundCode.mapOfGDgdjs_9546UndergroundCode_9546GDTeleporterObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Game Scene", false);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.UndergroundCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("Teleporter2"), gdjs.UndergroundCode.GDTeleporter2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.UndergroundCode.mapOfGDgdjs_9546UndergroundCode_9546GDPlayerObjects1Objects, gdjs.UndergroundCode.mapOfGDgdjs_9546UndergroundCode_9546GDTeleporter2Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(3).setNumber(1);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber() == 1);
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Death.wav", false, 80, 1);
}
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Game Scene", false);
}
{runtimeScene.getScene().getVariables().getFromIndex(3).setNumber(0);
}
}

}


{


let isConditionTrue_0 = false;
{
}

}


};

gdjs.UndergroundCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.UndergroundCode.GDCave_9595Under_9595TileObjects1.length = 0;
gdjs.UndergroundCode.GDCave_9595Under_9595TileObjects2.length = 0;
gdjs.UndergroundCode.GDBackgroundObjects1.length = 0;
gdjs.UndergroundCode.GDBackgroundObjects2.length = 0;
gdjs.UndergroundCode.GDWallObjects1.length = 0;
gdjs.UndergroundCode.GDWallObjects2.length = 0;
gdjs.UndergroundCode.GDMonsterObjects1.length = 0;
gdjs.UndergroundCode.GDMonsterObjects2.length = 0;
gdjs.UndergroundCode.GDCave_9595Under_9595Tile_9595DisappearObjects1.length = 0;
gdjs.UndergroundCode.GDCave_9595Under_9595Tile_9595DisappearObjects2.length = 0;
gdjs.UndergroundCode.GDPlayerObjects1.length = 0;
gdjs.UndergroundCode.GDPlayerObjects2.length = 0;
gdjs.UndergroundCode.GDJumpButtonObjects1.length = 0;
gdjs.UndergroundCode.GDJumpButtonObjects2.length = 0;
gdjs.UndergroundCode.GDMoveJoystickObjects1.length = 0;
gdjs.UndergroundCode.GDMoveJoystickObjects2.length = 0;
gdjs.UndergroundCode.GDKeyObjects1.length = 0;
gdjs.UndergroundCode.GDKeyObjects2.length = 0;
gdjs.UndergroundCode.GDTeleporterObjects1.length = 0;
gdjs.UndergroundCode.GDTeleporterObjects2.length = 0;
gdjs.UndergroundCode.GDCoinsObjects1.length = 0;
gdjs.UndergroundCode.GDCoinsObjects2.length = 0;
gdjs.UndergroundCode.GDTeleporter2Objects1.length = 0;
gdjs.UndergroundCode.GDTeleporter2Objects2.length = 0;

gdjs.UndergroundCode.eventsList0(runtimeScene);
gdjs.UndergroundCode.GDCave_9595Under_9595TileObjects1.length = 0;
gdjs.UndergroundCode.GDCave_9595Under_9595TileObjects2.length = 0;
gdjs.UndergroundCode.GDBackgroundObjects1.length = 0;
gdjs.UndergroundCode.GDBackgroundObjects2.length = 0;
gdjs.UndergroundCode.GDWallObjects1.length = 0;
gdjs.UndergroundCode.GDWallObjects2.length = 0;
gdjs.UndergroundCode.GDMonsterObjects1.length = 0;
gdjs.UndergroundCode.GDMonsterObjects2.length = 0;
gdjs.UndergroundCode.GDCave_9595Under_9595Tile_9595DisappearObjects1.length = 0;
gdjs.UndergroundCode.GDCave_9595Under_9595Tile_9595DisappearObjects2.length = 0;
gdjs.UndergroundCode.GDPlayerObjects1.length = 0;
gdjs.UndergroundCode.GDPlayerObjects2.length = 0;
gdjs.UndergroundCode.GDJumpButtonObjects1.length = 0;
gdjs.UndergroundCode.GDJumpButtonObjects2.length = 0;
gdjs.UndergroundCode.GDMoveJoystickObjects1.length = 0;
gdjs.UndergroundCode.GDMoveJoystickObjects2.length = 0;
gdjs.UndergroundCode.GDKeyObjects1.length = 0;
gdjs.UndergroundCode.GDKeyObjects2.length = 0;
gdjs.UndergroundCode.GDTeleporterObjects1.length = 0;
gdjs.UndergroundCode.GDTeleporterObjects2.length = 0;
gdjs.UndergroundCode.GDCoinsObjects1.length = 0;
gdjs.UndergroundCode.GDCoinsObjects2.length = 0;
gdjs.UndergroundCode.GDTeleporter2Objects1.length = 0;
gdjs.UndergroundCode.GDTeleporter2Objects2.length = 0;


return;

}

gdjs['UndergroundCode'] = gdjs.UndergroundCode;
